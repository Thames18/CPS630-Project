<?php
$mysqli = new mysqli('localhost', 'u746480298_root', 'ydz2v7cPs5Np', 'u746480298_phple');
?>