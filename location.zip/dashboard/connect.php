<?php
//$connect = mysqli_connect("localhost", "root", "", "foodbae");  
$connect  = mysqli_connect("localhost","u746480298_root","ydz2v7cPs5Np","u746480298_phple");
?>